/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        gold: {
          50: '#FFF9E6',
          100: '#FFF0BF',
          200: '#FFE799',
          300: '#FFDD73',
          400: '#FFD44D',
          500: '#D4AF37', // Primary gold
          600: '#C49B2C',
          700: '#A37C1F',
          800: '#7D5D14',
          900: '#5A420C',
        },
        navy: {
          50: '#E7E9EF',
          100: '#C2C9D6',
          200: '#9AA5BA',
          300: '#71819E',
          400: '#52658A',
          500: '#3A4A6B',
          600: '#2E3C58',
          700: '#232E45',
          800: '#182032',
          900: '#0A1128', // Primary navy
        },
      },
      fontFamily: {
        vazir: ['Vazirmatn', 'sans-serif'],
      },
      boxShadow: {
        gold: '0 0 20px 0 rgba(212, 175, 55, 0.3)',
      },
    },
  },
  plugins: [],
};