import React from 'react';
import { Check, X } from 'lucide-react';

interface PlanFeature {
  name: string;
  basic: boolean;
  pro: boolean;
  enterprise: boolean;
}

const PricingCard: React.FC<{
  name: string;
  price: string;
  description: string;
  features: string[];
  highlighted?: boolean;
}> = ({ name, price, description, features, highlighted }) => (
  <div className={`${
    highlighted 
      ? 'border-gold-500 bg-gradient-to-b from-navy-800 to-navy-700' 
      : 'border-navy-700 bg-navy-800'
  } border rounded-2xl p-8 relative`}>
    {highlighted && (
      <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
        <span className="bg-gold-500 text-navy-900 px-4 py-1 rounded-full text-sm font-bold">
          پیشنهاد ویژه
        </span>
      </div>
    )}
    <h3 className="text-2xl font-bold text-white mb-2">{name}</h3>
    <div className="mb-4">
      <span className="text-4xl font-bold text-gold-500">{price}</span>
      {price !== 'تماس بگیرید' && <span className="text-gray-400"> / ماهانه</span>}
    </div>
    <p className="text-gray-400 mb-6">{description}</p>
    <ul className="space-y-3 mb-8">
      {features.map((feature, index) => (
        <li key={index} className="flex items-center text-gray-300">
          <Check className="h-5 w-5 text-gold-500 ml-2 flex-shrink-0" />
          {feature}
        </li>
      ))}
    </ul>
    <button className={`w-full py-3 px-6 rounded-lg font-bold transition-all duration-300 ${
      highlighted
        ? 'bg-gold-500 hover:bg-gold-600 text-navy-900'
        : 'border border-gold-500 text-gold-500 hover:bg-gold-500/10'
    }`}>
      شروع کنید
    </button>
  </div>
);

const Pricing: React.FC = () => {
  const plans = [
    {
      name: 'پایه',
      price: '۱۵,۰۰۰,۰۰۰',
      description: 'مناسب برای کسب‌وکارهای کوچک',
      features: [
        'میزبانی اختصاصی',
        'پنل مدیریت پایه',
        'پشتیبانی ایمیل',
        'آپدیت‌های رایگان',
        'ظرفیت ۱۰۰ کاربر همزمان'
      ]
    },
    {
      name: 'حرفه‌ای',
      price: '۳۵,۰۰۰,۰۰۰',
      description: 'مناسب برای کسب‌وکارهای متوسط',
      features: [
        'تمام امکانات نسخه پایه',
        'اپلیکیشن موبایل اختصاصی',
        'پشتیبانی ۲۴/۷',
        'داشبورد پیشرفته تحلیل',
        'ظرفیت ۵۰۰ کاربر همزمان'
      ],
      highlighted: true
    },
    {
      name: 'سازمانی',
      price: 'تماس بگیرید',
      description: 'مناسب برای سازمان‌های بزرگ',
      features: [
        'تمام امکانات نسخه حرفه‌ای',
        'سفارشی‌سازی کامل',
        'پشتیبانی اختصاصی',
        'آموزش تیم شما',
        'ظرفیت نامحدود کاربر'
      ]
    }
  ];

  return (
    <section className="py-20 bg-navy-900">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white">
            تعرفه‌های <span className="text-gold-500">اوریو گلد</span>
          </h2>
          <p className="text-gray-400 max-w-3xl mx-auto">
            پلن مناسب کسب‌وکار خود را انتخاب کنید و همین امروز پلتفرم اختصاصی خود را راه‌اندازی کنید.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {plans.map((plan, index) => (
            <PricingCard key={index} {...plan} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Pricing;