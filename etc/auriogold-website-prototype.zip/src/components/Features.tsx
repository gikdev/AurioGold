import React from 'react';
import { Shield, Wallet, BarChart3, Star, DollarSign, ArrowRight } from 'lucide-react';

const FeatureCard: React.FC<{ icon: React.ReactNode; title: string; description: string }> = ({ 
  icon, 
  title, 
  description 
}) => (
  <div className="bg-navy-800 p-6 rounded-xl border border-navy-700 hover:border-gold-500/30 transition-all duration-300 hover:shadow-gold group">
    <div className="h-14 w-14 rounded-lg bg-gold-500/10 flex items-center justify-center mb-4 group-hover:bg-gold-500/20 transition-all duration-300">
      {icon}
    </div>
    <h3 className="text-xl font-bold mb-2 text-white">{title}</h3>
    <p className="text-gray-400">{description}</p>
  </div>
);

const Features: React.FC = () => {
  const features = [
    {
      icon: <Shield className="h-8 w-8 text-gold-500" />,
      title: "امنیت بالا",
      description: "سرمایه شما با بالاترین استانداردهای امنیتی و بیمه کامل محافظت می‌شود."
    },
    {
      icon: <Wallet className="h-8 w-8 text-gold-500" />,
      title: "کیف پول دیجیتال",
      description: "مدیریت آسان دارایی‌های طلا، سکه و نقره با کیف پول هوشمند اوریو"
    },
    {
      icon: <BarChart3 className="h-8 w-8 text-gold-500" />,
      title: "تحلیل بازار",
      description: "دسترسی به تحلیل‌های تخصصی و نمودارهای قیمت برای تصمیم‌گیری بهتر"
    },
    {
      icon: <Star className="h-8 w-8 text-gold-500" />,
      title: "محصولات متنوع",
      description: "امکان خرید انواع شمش، سکه و محصولات طلا با عیار و وزن‌های مختلف"
    },
    {
      icon: <DollarSign className="h-8 w-8 text-gold-500" />,
      title: "کارمزد پایین",
      description: "پایین‌ترین کارمزد معاملات در بازار با تخفیف‌های ویژه برای کاربران فعال"
    },
    {
      icon: <ArrowRight className="h-8 w-8 text-gold-500" />,
      title: "تحویل فیزیکی",
      description: "امکان تحویل فیزیکی طلا و سکه با بالاترین استانداردهای امنیتی"
    }
  ];

  return (
    <section className="py-20 bg-navy-900" id="خدمات">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white">
            چرا <span className="text-gold-500">اوریو گلد</span> را انتخاب کنید؟
          </h2>
          <p className="text-gray-400 max-w-3xl mx-auto">
            ما پلتفرمی امن و کاربرپسند برای سرمایه‌گذاری در طلا، سکه و نقره ارائه می‌دهیم
            که به شما امکان می‌دهد با خیال راحت و بدون نگرانی سرمایه‌گذاری کنید.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 text-right">
          {features.map((feature, index) => (
            <FeatureCard
              key={index}
              icon={feature.icon}
              title={feature.title}
              description={feature.description}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;