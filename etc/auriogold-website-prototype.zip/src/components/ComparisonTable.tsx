import React from 'react';
import { Check, X } from 'lucide-react';

const ComparisonTable: React.FC = () => {
  const features = [
    {
      category: 'امکانات اصلی',
      items: [
        {
          name: 'میزبانی اختصاصی',
          basic: true,
          pro: true,
          enterprise: true,
        },
        {
          name: 'پنل مدیریت',
          basic: true,
          pro: true,
          enterprise: true,
        },
        {
          name: 'اپلیکیشن موبایل',
          basic: false,
          pro: true,
          enterprise: true,
        },
        {
          name: 'سفارشی‌سازی کامل',
          basic: false,
          pro: false,
          enterprise: true,
        },
      ],
    },
    {
      category: 'پشتیبانی',
      items: [
        {
          name: 'پشتیبانی ایمیل',
          basic: true,
          pro: true,
          enterprise: true,
        },
        {
          name: 'پشتیبانی تلفنی',
          basic: false,
          pro: true,
          enterprise: true,
        },
        {
          name: 'پشتیبانی ۲۴/۷',
          basic: false,
          pro: true,
          enterprise: true,
        },
        {
          name: 'مدیر اختصاصی',
          basic: false,
          pro: false,
          enterprise: true,
        },
      ],
    },
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-navy-800 to-navy-900">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white">
            مقایسه <span className="text-gold-500">پلن‌ها</span>
          </h2>
          <p className="text-gray-400 max-w-3xl mx-auto">
            تمام امکانات پلن‌های مختلف را مقایسه کنید و بهترین انتخاب را برای کسب‌وکار خود داشته باشید.
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="border-b border-navy-700">
                <th className="p-4 text-right text-gray-400"></th>
                <th className="p-4 text-center text-white">پایه</th>
                <th className="p-4 text-center text-white">حرفه‌ای</th>
                <th className="p-4 text-center text-white">سازمانی</th>
              </tr>
            </thead>
            <tbody>
              {features.map((category, categoryIndex) => (
                <React.Fragment key={categoryIndex}>
                  <tr className="border-b border-navy-700 bg-navy-800/50">
                    <td colSpan={4} className="p-4 text-right text-gold-500 font-bold">
                      {category.category}
                    </td>
                  </tr>
                  {category.items.map((feature, featureIndex) => (
                    <tr key={featureIndex} className="border-b border-navy-700">
                      <td className="p-4 text-right text-gray-300">{feature.name}</td>
                      <td className="p-4 text-center">
                        {feature.basic ? (
                          <Check className="h-5 w-5 text-gold-500 mx-auto" />
                        ) : (
                          <X className="h-5 w-5 text-gray-600 mx-auto" />
                        )}
                      </td>
                      <td className="p-4 text-center">
                        {feature.pro ? (
                          <Check className="h-5 w-5 text-gold-500 mx-auto" />
                        ) : (
                          <X className="h-5 w-5 text-gray-600 mx-auto" />
                        )}
                      </td>
                      <td className="p-4 text-center">
                        {feature.enterprise ? (
                          <Check className="h-5 w-5 text-gold-500 mx-auto" />
                        ) : (
                          <X className="h-5 w-5 text-gray-600 mx-auto" />
                        )}
                      </td>
                    </tr>
                  ))}
                </React.Fragment>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
};

export default ComparisonTable;