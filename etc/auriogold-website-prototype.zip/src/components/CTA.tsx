import React from 'react';
import { ArrowLeft, Check } from 'lucide-react';

const CTA: React.FC = () => {
  return (
    <section className="py-20 bg-navy-900 relative overflow-hidden">
      <div className="absolute -right-20 -top-20 w-64 h-64 rounded-full bg-gold-500/10 blur-3xl"></div>
      <div className="absolute -left-20 -bottom-20 w-64 h-64 rounded-full bg-gold-500/10 blur-3xl"></div>
      
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div className="bg-gradient-to-r from-navy-800 to-navy-700 rounded-2xl p-8 md:p-12 border border-navy-600 shadow-xl overflow-hidden relative">
          
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-gold-400 via-gold-500 to-gold-400"></div>
          
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-2/3 mb-8 md:mb-0 text-right">
              <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white">
                پلتفرم اختصاصی خود را راه‌اندازی کنید
              </h2>
              <p className="text-gray-300 mb-6">
                با اوریو گلد، در کمترین زمان صاحب پلتفرم اختصاصی خرید و فروش طلا شوید. همراه با پشتیبانی ۲۴/۷ و آپدیت‌های منظم.
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                {[
                  "میزبانی اختصاصی و امن",
                  "پنل مدیریت پیشرفته",
                  "اپلیکیشن موبایل اختصاصی",
                  "پشتیبانی ۲۴/۷"
                ].map((item, index) => (
                  <div key={index} className="flex items-center">
                    <Check className="h-5 w-5 text-gold-500 ml-2 flex-shrink-0" />
                    <span className="text-gray-300">{item}</span>
                  </div>
                ))}
              </div>
              
              <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 sm:space-x-reverse">
                <button className="bg-gold-500 hover:bg-gold-600 text-navy-900 font-bold py-3 px-8 rounded-lg transition-all duration-300 transform hover:-translate-y-1 flex items-center justify-center">
                  <span>درخواست دمو</span>
                  <ArrowLeft className="h-5 w-5 mr-2" />
                </button>
                <button className="border border-gold-500 text-gold-500 hover:bg-gold-500/10 font-bold py-3 px-8 rounded-lg transition-all duration-300">
                  مشاوره رایگان
                </button>
              </div>
            </div>
            
            <div className="md:w-1/3 relative">
              <div className="relative mx-auto w-64 h-64">
                <img 
                  src="https://images.pexels.com/photos/6771900/pexels-photo-6771900.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                  alt="Gold investment platform" 
                  className="rounded-full object-cover w-full h-full border-4 border-gold-500 shadow-2xl"
                />
                <div className="absolute -bottom-4 left-1/2 transform -translate-x-1/2 bg-navy-800 border border-navy-700 rounded-xl py-2 px-6 shadow-lg">
                  <span className="text-gold-500 font-bold">راه‌اندازی سریع</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTA;