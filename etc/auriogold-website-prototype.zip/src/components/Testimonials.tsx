import React from 'react';
import { Star } from 'lucide-react';

interface TestimonialProps {
  quote: string;
  name: string;
  title: string;
  rating: number;
  image: string;
}

const Testimonial: React.FC<TestimonialProps> = ({ quote, name, title, rating, image }) => (
  <div className="bg-navy-800 p-6 rounded-xl border border-navy-700 shadow-lg">
    <div className="flex mb-4">
      {Array.from({ length: 5 }).map((_, i) => (
        <Star
          key={i}
          className={`h-5 w-5 ${i < rating ? 'text-gold-500 fill-gold-500' : 'text-gray-600'}`}
        />
      ))}
    </div>
    <p className="text-gray-300 mb-6 text-right">{quote}</p>
    <div className="flex items-center">
      <div className="mr-4 flex-grow text-right">
        <h4 className="text-white font-bold">{name}</h4>
        <p className="text-gray-400 text-sm">{title}</p>
      </div>
      <img
        src={image}
        alt={name}
        className="h-12 w-12 rounded-full object-cover border-2 border-gold-500"
      />
    </div>
  </div>
);

const Testimonials: React.FC = () => {
  const testimonials = [
    {
      quote: "اوریو گلد به من کمک کرد تا به راحتی سرمایه‌گذاری در طلا را شروع کنم. رابط کاربری ساده و قیمت‌های رقابتی واقعاً عالی است.",
      name: "محمد احمدی",
      title: "سرمایه‌گذار",
      rating: 5,
      image: "https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=600"
    },
    {
      quote: "من همیشه می‌خواستم در طلا سرمایه‌گذاری کنم اما نگران امنیت بودم. اوریو گلد تمام نگرانی‌های من را برطرف کرد.",
      name: "سارا محمدی",
      title: "فریلنسر",
      rating: 5,
      image: "https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=600"
    },
    {
      quote: "تحلیل‌های بازار و اطلاعات به‌روز اوریو گلد به من کمک کرد تا تصمیمات بهتری برای سرمایه‌گذاری بگیرم. واقعاً راضی هستم.",
      name: "علی رضایی",
      title: "مدیر مالی",
      rating: 4,
      image: "https://images.pexels.com/photos/1516680/pexels-photo-1516680.jpeg?auto=compress&cs=tinysrgb&w=600"
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-navy-900 to-navy-800">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white">
            مشتریان ما چه می‌گویند
          </h2>
          <p className="text-gray-400 max-w-3xl mx-auto">
            هزاران نفر از سراسر ایران به اوریو گلد برای سرمایه‌گذاری در طلا و فلزات گرانبها اعتماد کرده‌اند.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Testimonial
              key={index}
              quote={testimonial.quote}
              name={testimonial.name}
              title={testimonial.title}
              rating={testimonial.rating}
              image={testimonial.image}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;