import React, { useState, useEffect } from 'react';
import { Menu, X, Coins } from 'lucide-react';

const Header: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const offset = window.scrollY;
      if (offset > 50) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <header 
      className={`fixed w-full z-50 transition-all duration-300 ${
        scrolled 
          ? 'bg-navy-900 shadow-lg py-3' 
          : 'bg-transparent py-5'
      }`}
    >
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <Coins className="h-8 w-8 text-gold-500 mr-2" />
            <span className="text-2xl font-bold text-white">
              <span className="text-gold-500">Aurio</span> Gold
            </span>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            {['خانه', 'خدمات', 'مزایا', 'سوالات متداول', 'تماس با ما'].map((item) => (
              <a 
                key={item} 
                href={`#${item}`} 
                className="text-white hover:text-gold-400 transition-colors duration-300 font-medium"
              >
                {item}
              </a>
            ))}
            <button className="bg-gold-500 hover:bg-gold-600 text-navy-900 font-bold py-2 px-4 rounded-lg transition-colors duration-300">
              شروع کنید
            </button>
          </nav>

          {/* Mobile Navigation Toggle */}
          <button 
            className="md:hidden text-white"
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation Menu */}
        {isOpen && (
          <div className="md:hidden mt-4 py-4 bg-navy-800 rounded-lg">
            <nav className="flex flex-col space-y-4 items-center">
              {['خانه', 'خدمات', 'مزایا', 'سوالات متداول', 'تماس با ما'].map((item) => (
                <a 
                  key={item} 
                  href={`#${item}`} 
                  className="text-white hover:text-gold-400 transition-colors duration-300 font-medium"
                  onClick={() => setIsOpen(false)}
                >
                  {item}
                </a>
              ))}
              <button className="bg-gold-500 hover:bg-gold-600 text-navy-900 font-bold py-2 px-4 rounded-lg transition-colors duration-300 w-2/3">
                شروع کنید
              </button>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;