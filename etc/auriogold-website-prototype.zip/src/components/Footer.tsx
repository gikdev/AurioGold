import React from 'react';
import { Coins, Instagram, Twitter, Linkedin, Mail, Phone } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-navy-900 text-white border-t border-navy-700 py-12">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 text-right">
          <div>
            <div className="flex items-center mb-4">
              <Coins className="h-8 w-8 text-gold-500 ml-2" />
              <span className="text-2xl font-bold">
                <span className="text-gold-500">اوریو</span> گلد
              </span>
            </div>
            <p className="text-gray-400 mb-6">
              امن‌ترین و آسان‌ترین راه برای خرید، فروش و نگهداری طلا، سکه و نقره
            </p>
            <div className="flex space-x-4 space-x-reverse">
              {[Instagram, Twitter, Linkedin].map((Icon, index) => (
                <a 
                  key={index}
                  href="#" 
                  className="bg-navy-800 hover:bg-gold-500 h-10 w-10 rounded-full flex items-center justify-center transition-colors duration-300 group"
                >
                  <Icon size={20} className="text-gray-400 group-hover:text-navy-900" />
                </a>
              ))}
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-6 text-white">خدمات</h3>
            <ul className="space-y-3">
              {[
                'خرید و فروش طلا',
                'خرید و فروش سکه',
                'خرید و فروش نقره',
                'نگهداری دارایی',
                'کیف پول دیجیتال'
              ].map((item, index) => (
                <li key={index}>
                  <a href="#" className="text-gray-400 hover:text-gold-500 transition-colors duration-300">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-6 text-white">لینک‌های مفید</h3>
            <ul className="space-y-3">
              {[
                'درباره ما',
                'سوالات متداول',
                'قوانین و مقررات',
                'حریم خصوصی',
                'وبلاگ'
              ].map((item, index) => (
                <li key={index}>
                  <a href="#" className="text-gray-400 hover:text-gold-500 transition-colors duration-300">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-6 text-white">تماس با ما</h3>
            <ul className="space-y-4">
              <li className="flex items-center">
                <Mail className="h-5 w-5 text-gold-500 ml-3" />
                <span className="text-gray-400">info@auriogold.ir</span>
              </li>
              <li className="flex items-center">
                <Phone className="h-5 w-5 text-gold-500 ml-3" />
                <span className="text-gray-400">۰۲۱-۱۲۳۴۵۶۷۸</span>
              </li>
              <li className="text-gray-400">
                تهران، خیابان ولیعصر، برج طلا، طبقه ۱۰
              </li>
            </ul>
          </div>
        </div>
        
        <div className="mt-12 pt-8 border-t border-navy-700 text-center">
          <p className="text-gray-500">
            © ۱۴۰۴ اوریو گلد. تمامی حقوق محفوظ است.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;