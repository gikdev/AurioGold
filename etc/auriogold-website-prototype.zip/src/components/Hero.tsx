import React from 'react';
import { TrendingUp, Shield, Clock } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="pt-28 pb-20 bg-gradient-to-b from-navy-900 to-navy-800 text-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex flex-col-reverse md:flex-row items-center">
          <div className="md:w-1/2 mt-10 md:mt-0 text-right">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
              پلتفرم اختصاصی <span className="text-gold-500">خرید و فروش طلا</span>
              <br />برای کسب و کار شما
            </h1>
            <p className="text-lg md:text-xl mb-8 text-gray-300">
              اوریو گلد، راهکار کامل و امن برای راه‌اندازی پلتفرم خرید و فروش طلا، سکه و نقره. با قابلیت میزبانی اختصاصی و مدیریت کامل کسب و کار شما.
            </p>
            
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 sm:space-x-reverse justify-start">
              <button className="bg-gold-500 hover:bg-gold-600 text-navy-900 font-bold py-3 px-8 rounded-lg transition-all duration-300 transform hover:-translate-y-1 text-lg order-last sm:order-first">
                درخواست دمو
              </button>
              <button className="border border-gold-500 text-gold-500 hover:bg-gold-500/10 font-bold py-3 px-8 rounded-lg transition-all duration-300 text-lg">
                مشاهده قیمت‌ها
              </button>
            </div>
            
            <div className="mt-12 grid grid-cols-1 sm:grid-cols-3 gap-6">
              <div className="flex items-center">
                <TrendingUp className="h-8 w-8 text-gold-500 ml-3" />
                <div>
                  <h3 className="font-bold">میزبانی اختصاصی</h3>
                  <p className="text-sm text-gray-400">کنترل کامل پلتفرم</p>
                </div>
              </div>
              <div className="flex items-center">
                <Shield className="h-8 w-8 text-gold-500 ml-3" />
                <div>
                  <h3 className="font-bold">امنیت پیشرفته</h3>
                  <p className="text-sm text-gray-400">استانداردهای بانکی</p>
                </div>
              </div>
              <div className="flex items-center">
                <Clock className="h-8 w-8 text-gold-500 ml-3" />
                <div>
                  <h3 className="font-bold">راه‌اندازی سریع</h3>
                  <p className="text-sm text-gray-400">در کمتر از ۲۴ ساعت</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="md:w-1/2 relative">
            <div className="relative overflow-hidden rounded-2xl shadow-2xl">
              <img 
                src="https://images.pexels.com/photos/4386366/pexels-photo-4386366.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="Gold coins and bars" 
                className="w-full object-cover h-[400px]"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-navy-900/70 to-transparent"></div>
              
              <div className="absolute bottom-6 left-6 bg-white/10 backdrop-blur-md rounded-xl p-4 border border-gold-500/30 animate-float">
                <div className="flex items-center">
                  <div className="w-8 h-8 rounded-full bg-gold-500 flex items-center justify-center mr-3">
                    <span className="font-bold text-navy-900">Au</span>
                  </div>
                  <div>
                    <p className="text-sm text-gray-300">پلتفرم اختصاصی شما</p>
                    <p className="font-bold text-gold-400">آماده راه‌اندازی</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;