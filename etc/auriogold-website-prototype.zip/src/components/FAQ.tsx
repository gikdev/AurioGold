import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

interface FAQItemProps {
  question: string;
  answer: string;
}

const FAQItem: React.FC<FAQItemProps> = ({ question, answer }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="border-b border-navy-700 last:border-0">
      <button
        className="w-full py-6 flex justify-between items-center text-right"
        onClick={() => setIsOpen(!isOpen)}
      >
        <span className="text-lg font-medium text-white">{question}</span>
        {isOpen ? (
          <ChevronUp className="h-5 w-5 text-gold-500" />
        ) : (
          <ChevronDown className="h-5 w-5 text-gold-500" />
        )}
      </button>
      <div
        className={`overflow-hidden transition-all duration-300 ${
          isOpen ? 'max-h-96 pb-6' : 'max-h-0'
        }`}
      >
        <p className="text-gray-400">{answer}</p>
      </div>
    </div>
  );
};

const FAQ: React.FC = () => {
  const faqs = [
    {
      question: 'نحوه راه‌اندازی پلتفرم چگونه است؟',
      answer: 'پس از انتخاب پلن مورد نظر و تکمیل فرآیند خرید، تیم فنی ما در کمتر از ۲۴ ساعت پلتفرم شما را راه‌اندازی می‌کند. سپس آموزش‌های لازم برای مدیریت پلتفرم به شما ارائه می‌شود.'
    },
    {
      question: 'آیا امکان سفارشی‌سازی رابط کاربری وجود دارد؟',
      answer: 'بله، در تمامی پلن‌ها امکان شخصی‌سازی رنگ‌ها و لوگو وجود دارد. در پلن سازمانی، امکان سفارشی‌سازی کامل رابط کاربری نیز فراهم است.'
    },
    {
      question: 'پشتیبانی و آپدیت‌ها به چه صورت است؟',
      answer: 'تمامی پلن‌ها شامل آپدیت‌های رایگان و امنیتی هستند. پشتیبانی بر اساس نوع پلن انتخابی، از پشتیبانی ایمیل تا پشتیبانی ۲۴/۷ متغیر است.'
    },
    {
      question: 'آیا اپلیکیشن موبایل هم دارید؟',
      answer: 'بله، در پلن‌های حرفه‌ای و سازمانی، اپلیکیشن موبایل اختصاصی با برند شما ارائه می‌شود که قابل انتشار در مارکت‌های ایرانی و خارجی است.'
    },
    {
      question: 'امنیت پلتفرم چگونه تضمین می‌شود؟',
      answer: 'ما از بالاترین استانداردهای امنیتی و رمزنگاری استفاده می‌کنیم. تمام تراکنش‌ها با SSL/TLS محافظت می‌شوند و دیتاسنتر ما دارای گواهینامه‌های امنیتی معتبر است.'
    }
  ];

  return (
    <section className="py-20 bg-navy-900">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white">
            سوالات <span className="text-gold-500">متداول</span>
          </h2>
          <p className="text-gray-400 max-w-3xl mx-auto">
            پاسخ سوالات رایج شما درباره پلتفرم اوریو گلد
          </p>
        </div>

        <div className="max-w-3xl mx-auto bg-navy-800 rounded-2xl p-8">
          {faqs.map((faq, index) => (
            <FAQItem key={index} question={faq.question} answer={faq.answer} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default FAQ;